INSTRUCTIONS
1. Please Change the path directory of dataset KDDCup99.csv before running the .ipynb file
2. Please install any missing modules by removing the '#', if module packet has change name, follow the latest package available
